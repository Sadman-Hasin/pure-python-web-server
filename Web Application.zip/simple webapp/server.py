import socket
import threading
from PIL import Image

class Server(object):
	def __init__(self, host=socket.gethostbyname(socket.gethostname()), port=80):
		self.host = host
		self.port = port

	def response(self, conn, Response):
		conn.send(Response)
		conn.close()

	def handle_clinet(self, conn, addr):
		"""
		** Main Loop For Handling Connection. **
		Parameters: 
			- conn -> Socket Obj from self.server.accept()
			- addr -> Socket addr from self.server.accept()
		"""
		try:
			REQUEST_HEADER = RequestHeader(conn).requestHeader()
			if REQUEST_HEADER:
				REQUEST_METHOD, REQUEST_FILE, HTTP_TYPE, POST_DATA, COOKIE = REQUEST_HEADER
				print(REQUEST_METHOD, REQUEST_FILE, HTTP_TYPE, POST_DATA, COOKIE)

				if REQUEST_METHOD == "GET":
					if REQUEST_FILE == "/index" or REQUEST_FILE == "/":
						index_file = bytes(f"HTTP/1.1 200 OK\r\n\r\n{open('templates/index.html', 'r').read()}", "UTF-8")
						self.response(conn, index_file)
					elif REQUEST_FILE == "/images/background.jpg":
						print("[MESSAGE] I was lazy to make image render method. Please build your own or use any package (Jinja2).")
						self.response(conn, b"HTTP/1.1 200 OK\r\n\r\n")

					else:
						try:
							content_type = "text/plain"
							if REQUEST_FILE.find(".css") != -1:
								content_type = "text/css"
							elif REQUEST_FILE.find(".js") != -1:
								content_type = "text/javascript"

							file = bytes(f"HTTP/1.1 200 OK\r\nContent-Type: {content_type}\r\n\r\n{open(f'static{REQUEST_FILE}', 'r').read()}", "UTF-8")
							self.response(conn, file)

						except Exception as err:
							self.response(conn, b"HTTP/1.1 404 Not Found\r\n")

		except Exception as Error:
			self.response(conn, b"HTTP/1.1 500 Internal Server Error\r\n")
			conn.close()
			print(f"[ERROR - Server.handle_client] {Error}")

	def listen_for_connection(self):
		# Listens For Any Incoming Connection to Connect.

		self.server.listen()
		print("[LISTENING] Server is Listening For Connections.")

		while True:
			conn, addr = self.server.accept()
			threading.Thread(target=self.handle_clinet, args=(conn, addr)).start()

	def start(self):
		# Creates and Bind with a Socket to Launch Server.

		self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		try:
			self.server.bind((self.host, self.port))
			print(f"[STARTED] Server Started on '{self.host}:{self.port}'")
			self.listen_for_connection()

		except Exception as Error:
			print(Error)
			print(f"[ERROR - Server.start] Couldn't Start Server on '{self.host}:{self.port}")


class RequestHeader():
	def __init__(self, client):
		self.client = client
		self.PACKET_SIZE = 1024
		self.header = self.getHeader()

	def getHeaderSize(self, header):
		size = False

		header = header.split('\r\n')
		for headerElement in header:
			if headerElement.find('Content-Length: ') != -1:
				size = int(headerElement.split(': ')[1])

		return size

	def getHeader(self):
		# Getting requests at first stage (For GET methods).
		header = self.client.recv(self.PACKET_SIZE).decode()

		# Getting requests at second stage (If POST method and containing any Files).
		size = self.getHeaderSize(header)
		if size and size > 1024:
			header += self.client.recv(size).decode()

		return header

	def getPostData(self, REQUEST_METHOD, header):
		POST_DATA = ""
		if REQUEST_METHOD == 'POST':
			POST_DATA = header[-1]

		return POST_DATA

	def getCookie(self, header):
		# params -> header (list);
		COOKIE = ""

		for headerElement in header:
			if headerElement.find('Cookie: ') != -1:
				COOKIE = headerElement.split(': ')[1]

		return COOKIE

	def requestHeader(self):
		if self.header:
			header = self.header.split('\r\n')

			# Header method, file, httpVersion 
			self.REQUEST_METHOD = header[0].split(' ')[0]
			self.REQUEST_FILE = header[0].split(' ')[1]
			self.HTTP_TYPE = header[0].split(' ')[2]

			# others
			self.POST_DATA = self.getPostData(self.REQUEST_METHOD, header)
			self.COOKIE = self.getCookie(header)

			return self.REQUEST_METHOD, self.REQUEST_FILE, self.HTTP_TYPE, self.POST_DATA, self.COOKIE

		return False

server = Server(host='127.0.0.1', port=5000)
server.start()